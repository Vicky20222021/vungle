
#include "VunglePrivatePCH.h"
#include "VungleSettings.h"

UVungleSettings::UVungleSettings(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{
}
